# auto podcast

## by jake
#

this project is made using python



it scrapes the URL (readit) that **you** 
put in

and it does all of these:

* gets the name of the post
* the username who posted (WIP)
* the subreadit (WIP)
* turns all that into a script
* witch is proccsed thru GTT

what may come:

* auto post in spotify or youtube

# 

version 0.8.1 beta



